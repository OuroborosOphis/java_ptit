
package kiemtra1;

import java.util.Scanner;

public class sothuc {
    private double x, e;
    
    public void nhapSoThuc(){
        Scanner sc = new Scanner(System.in);
        x = sc.nextDouble();
        e = sc.nextDouble();
    }
}
